there are 6 variables in each .mat file.

Their meanings are as follows:
examples--matrix containing the feature values for all instances (column corresponds to feature, row to instance)
labels--vector containing the labels of all instances
ids--the id for each instance
feature_names--names for all features
is_nominal-- vector indicating whether features are nominal (1 means the corresponding feature is nominal)
nominal_values--cell vector containing all the possible values that can be taken on by each nominal feature